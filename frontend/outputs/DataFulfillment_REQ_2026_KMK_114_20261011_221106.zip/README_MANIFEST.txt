================================================================================
PAKET PEMENUHAN PERMOHONAN DATA RESMI (DATA FULFILLMENT PACKAGE)
DataRequest Studio — Enterprise Data Requisition & Governance Platform
Direktorat Informasi Kepabeanan dan Cukai (DIKC) - DJBC
================================================================================
ID Permohonan      : REQ-2026-KMK-114
Dokumen            : FORMULIR PERMOHONAN REKONSILIASI DATA TRANSAKSI PENERIMAAN NEGARA
Pemohon            : Siti Sarah, S.T. (Internal Kemenkeu)
Tujuan             : Data
Periode Data       : 2026-07-01 s/d 2026-09-30
Status Verifikasi  : APPROVED
Auditor            : Agent-Independent-Auditor-v2 (2026-10-13T04:50:30.804671+00:00)
Digital Fingerprint: SHA256:f375f759e835f3f0fede5ea115eb90d74e6aac349f6d731a7ef717791b6fbaf2
Dasar Kepatuhan    : UU No. 27/2022 (UU PDP) & PP No. 33/2026 (Peraturan Pelaksanaan PDP)
Proteksi PII       : Aktif (Masking Dinamis NIK, NPWP, Nama, dan No HP - Ps. 123 PP 33/2026)
Retensi & Sanitasi : Wajib dimusnahkan dalam 30 hari kalender & menyampaikan Berita Acara / CoD
Insiden PDP        : Wajib lapor < 24 jam ke PPDP DIKC & maks 3x24 jam ke Lembaga PDP (Ps. 114 PP 33/2026)

BERKAS DALAM PAKET INI:
1. DataExport_REQ_2026_KMK_114_20261013_115030.xlsx  - Workbook Excel 4 Sheet (Data Hasil + Subtotal Dinamis, Audit Provenance, Kamus Data OpenMetadata, Profiling Kualitas Data)
2. DataExport_REQ_2026_KMK_114_20261013_115030.csv    - Raw Data CSV (UTF-8)
3. DataExport_REQ_2026_KMK_114_20261013_115030.json   - Raw Data JSON (Machine-Readable Records)
4. Sertifikat_Otorisasi_REQ_2026_KMK_114_20261013_115030.pdf   - Sertifikat Otorisasi & Tata Kelola Data (PDF - UU PDP & PP 33/2026)
5. query_audit.sql                  - Query SQL yang dieksekusi
6. request_specification.json       - Struktur spesifikasi kebutuhan hasil ekstraksi PDF
7. audit_verification_report.json   - Checklist kepatuhan dan jaminan keamanan
================================================================================

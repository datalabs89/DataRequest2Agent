-- ====================================================================
-- Query Otomatis Dibuat oleh DataRequest2Agent
-- Berdasarkan Dokumen: FORMULIR RESMI PERMOHONAN AKSES & EKSTRAKSI DATA KEPABEANAN (ID: REQ-2026-BC-089)
-- Pemohon: Ahmad Fauzi, S.Kom (Internal Bea dan Cukai)
-- Metadata Divalidasi via: OpenMetadata Service CEISA40-PostgreSQL-DWH
-- Target Database: PostgreSQL
-- ====================================================================

SELECT
    t.nomor_peb,
    CONCAT(SUBSTRING(t.npwp_eksportir, 1, 6), '******', SUBSTRING(t.npwp_eksportir, LENGTH(t.npwp_eksportir)-3, 4)) AS npwp_eksportir_masked,
    t.nilai_devisa_idr,
    t.status_pabean
FROM dwh_ceisa.ekspor.fct_peb_ekspor AS t
INNER JOIN dwh_ceisa.fasilitas.dim_customers AS s
    ON fct_transactions.customer_id = s.customer_id
WHERE
    t.tanggal_peb >= '01 Juli 2026 00:00:00'
  AND t.tanggal_peb <= '30 September 2026 23:59:59'
  AND t.status_pabean = 'NPE'
  AND c.customer_segment = 'PRIORITAS'
ORDER BY
    t.tanggal_peb DESC
LIMIT 500;
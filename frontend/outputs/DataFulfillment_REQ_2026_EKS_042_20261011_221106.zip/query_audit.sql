-- ====================================================================
-- Query Otomatis Dibuat oleh DataRequestStudio
-- Berdasarkan Dokumen: SURAT PERMINTAAN DATA DUKUNG PENGAWASAN & AUDIT KEPATUHAN NEGARA (ID: REQ-2026-EKS-042)
-- Pemohon: Bambang Pratama, S.H., M.H. (Eksternal Kemenkeu)
-- Metadata Divalidasi via: OpenMetadata Service CEISA40-PostgreSQL-DWH
-- Target Database: PostgreSQL
-- ====================================================================

SELECT
    t.nomor_peb,
    CONCAT(SUBSTRING(t.npwp_eksportir, 1, 6), '******', SUBSTRING(t.npwp_eksportir, LENGTH(t.npwp_eksportir)-3, 4)) AS npwp_eksportir_masked,
    t.nilai_devisa_idr,
    t.status_pabean,
    c.kategori_layanan_aeo,
    CONCAT(SUBSTRING(c.nik_penanggung_jawab, 1, 6), '******', SUBSTRING(c.nik_penanggung_jawab, 13, 4)) AS nik_penanggung_jawab_masked
FROM dwh_ceisa.ekspor.fct_peb_ekspor AS t
INNER JOIN dwh_ceisa.master.dim_perusahaan AS s
    ON t.npwp_eksportir = s.npwp_perusahaan
INNER JOIN dwh_ceisa.master.dim_perusahaan AS s
    ON fct_transactions.npwp_eksportir = s.npwp_perusahaan
WHERE
    t.tanggal_peb >= '01 Juli 2026 00:00:00'
  AND t.tanggal_peb <= '30 September 2026 23:59:59'
  AND t.status_pabean = 'NPE'
ORDER BY
    t.tanggal_peb DESC
LIMIT 500;
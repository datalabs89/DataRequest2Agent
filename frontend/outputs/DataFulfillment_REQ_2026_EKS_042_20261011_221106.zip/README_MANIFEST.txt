================================================================================
PAKET PEMENUHAN PERMOHONAN DATA RESMI (DATA FULFILLMENT PACKAGE)
DataRequest Studio — Enterprise Data Requisition & Governance Platform
Direktorat Informasi Kepabeanan dan Cukai (DIKC) - DJBC
================================================================================
ID Permohonan      : REQ-2026-EKS-042
Dokumen            : SURAT PERMINTAAN DATA DUKUNG PENGAWASAN & AUDIT KEPATUHAN NEGARA
Pemohon            : Bambang Pratama, S.H., M.H. (Eksternal Kemenkeu)
Tujuan             : Data
Periode Data       : 01 Juli 2026 s/d 30 September 2026
Status Verifikasi  : APPROVED
Auditor            : Agent-Independent-Auditor-v2 (2026-10-13T04:50:31.028664+00:00)
Digital Fingerprint: SHA256:771da77fde0f0113135e87b08f6a4deec3dffef64fb30763eeef6c3552bb9246
Dasar Kepatuhan    : UU No. 27/2022 (UU PDP) & PP No. 33/2026 (Peraturan Pelaksanaan PDP)
Proteksi PII       : Aktif (Masking Dinamis NIK, NPWP, Nama, dan No HP - Ps. 123 PP 33/2026)
Retensi & Sanitasi : Wajib dimusnahkan dalam 30 hari kalender & menyampaikan Berita Acara / CoD
Insiden PDP        : Wajib lapor < 24 jam ke PPDP DIKC & maks 3x24 jam ke Lembaga PDP (Ps. 114 PP 33/2026)

BERKAS DALAM PAKET INI:
1. DataExport_REQ_2026_EKS_042_20261013_115031.xlsx  - Workbook Excel 4 Sheet (Data Hasil + Subtotal Dinamis, Audit Provenance, Kamus Data OpenMetadata, Profiling Kualitas Data)
2. DataExport_REQ_2026_EKS_042_20261013_115031.csv    - Raw Data CSV (UTF-8)
3. DataExport_REQ_2026_EKS_042_20261013_115031.json   - Raw Data JSON (Machine-Readable Records)
4. Sertifikat_Otorisasi_REQ_2026_EKS_042_20261013_115031.pdf   - Sertifikat Otorisasi & Tata Kelola Data (PDF - UU PDP & PP 33/2026)
5. query_audit.sql                  - Query SQL yang dieksekusi
6. request_specification.json       - Struktur spesifikasi kebutuhan hasil ekstraksi PDF
7. audit_verification_report.json   - Checklist kepatuhan dan jaminan keamanan
================================================================================

================================================================================
PAKET PEMENUHAN PERMOHONAN DATA RESMI (DATA FULFILLMENT PACKAGE)
DataRequest Studio — Enterprise Data Requisition & Governance Platform
Direktorat Informasi Kepabeanan dan Cukai (DIKC) - DJBC
================================================================================
ID Permohonan      : REQ-2026-BC-089
Dokumen            : Permohonan Data Ekspor Anode Slime Q3 2026
Pemohon            : Ahmad Fauzi, S.Kom (Internal Bea dan Cukai)
Tujuan             : Analisis anomali devisa ekspor dan verifikasi kepatuhan penerimaan Bea Keluar.
Periode Data       : 2026-07-01 s/d 2026-09-30
Status Verifikasi  : APPROVED_BY_STEWARD
Auditor            : Agent-Independent-Auditor-v2 (2026-10-13T07:25:00Z)
Digital Fingerprint: SHA256:A1B2C3D4E5F67890123456789ABCDEF0123456789ABCDEF0123456789ABCDEF0
Dasar Kepatuhan    : UU No. 27/2022 (UU PDP) & PP No. 33/2026 (Peraturan Pelaksanaan PDP)
Proteksi PII       : Aktif (Masking Dinamis NIK, NPWP, Nama, dan No HP - Ps. 123 PP 33/2026)
Retensi & Sanitasi : Wajib dimusnahkan dalam 30 hari kalender & menyampaikan Berita Acara / CoD
Insiden PDP        : Wajib lapor < 24 jam ke PPDP DIKC & maks 3x24 jam ke Lembaga PDP (Ps. 114 PP 33/2026)

REVIEW & PERSETUJUAN VERIFIKATOR:
Reviewer           : Hendra Gunawan, S.Kom (Kepala Seksi Analisa dan Layanan Data)
Pejabat PDP (DPO)  : Tim PPDP / DPO DIKC DJBC (Pejabat Pelaksana Fungsi Pelindungan Data Pribadi)
Keputusan          : APPROVE
Catatan Kepatuhan  : Data disetujui untuk analisis kedinasan resmi. Wajib patuh UU No. 27/2022 & PP No. 33/2026: Masking dinamis aktif, retensi maks 30 hari kalender, pemusnahan wajib (CoD) pasca-analisis, dan dilarang transfer ke pihak ketiga.
Masa Retensi Wajib : 30 Hari Kalender (Wajib Pemusnahan / CoD pasca-retensi - Ps. 75 PP 33/2026)
Waktu Sign-Off     : 2026-10-13T07:30:00Z

BERKAS DALAM PAKET INI:
1. DataExport_REQ_2026_BC_089_20261013_073215.xlsx  - Workbook Excel (Data Hasil, Audit Provenance, Kamus Data)
2. DataExport_REQ_2026_BC_089_20261013_073215.csv    - Raw Data CSV (UTF-8)
3. DataExport_REQ_2026_BC_089_20261013_073215.json   - Raw Data JSON (Machine-Readable Records)
4. Sertifikat_Otorisasi_REQ_2026_BC_089_20261013_073215.pdf   - Sertifikat Otorisasi & Tata Kelola Data (PDF - UU PDP & PP 33/2026)
5. query_audit.sql                  - Query SQL yang dieksekusi
6. request_specification.json       - Struktur spesifikasi kebutuhan hasil ekstraksi PDF
7. audit_verification_report.json   - Checklist kepatuhan dan jaminan keamanan
================================================================================

================================================================================
PAKET PEMENUHAN PERMOHONAN DATA RESMI (DATA FULFILLMENT PACKAGE)
DataRequest Studio — Enterprise Data Requisition & Governance Platform
================================================================================
ID Permohonan      : REQ-2026-KMK-114
Dokumen            : FORMULIR PERMOHONAN REKONSILIASI DATA TRANSAKSI PENERIMAAN NEGARA
Pemohon            : Siti Sarah, S.T. (Internal Kemenkeu)
Tujuan             : Data
Periode Data       : 2026-07-01 s/d 2026-09-30
Status Verifikasi  : APPROVED
Auditor            : Agent-Independent-Auditor-v2 (2026-10-11T15:11:06.510612+00:00)
Digital Fingerprint: SHA256:cccc228d088f9d4ab571f032e489e06182efd62470796942a949ef04c7ae031b
Proteksi PII       : Aktif (Masking NIK, Nama, dan No HP)

BERKAS DALAM PAKET INI:
1. DataExport_REQ_2026_KMK_114_20261011_221106.xlsx  - Workbook Excel (Data Hasil, Audit, Kamus Data)
2. DataExport_REQ_2026_KMK_114_20261011_221106.csv    - Raw Data CSV (UTF-8)
3. DataExport_REQ_2026_KMK_114_20261011_221106.json   - Raw Data JSON (Machine-Readable Records)
4. Sertifikat_Otorisasi_REQ_2026_KMK_114_20261011_221106.pdf   - Sertifikat Otorisasi & Tata Kelola Data (PDF)
5. query_audit.sql                  - Query SQL yang dieksekusi
6. request_specification.json       - Struktur spesifikasi kebutuhan hasil ekstraksi PDF
7. audit_verification_report.json   - Checklist kepatuhan dan jaminan keamanan
================================================================================

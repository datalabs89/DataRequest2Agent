-- ====================================================================
-- Query Otomatis Dibuat oleh DataRequest2Agent
-- Berdasarkan Dokumen: FORMULIR PERMOHONAN REKONSILIASI DATA TRANSAKSI PENERIMAAN NEGARA (ID: REQ-2026-KMK-114)
-- Pemohon: Siti Sarah, S.T. (Internal Kemenkeu)
-- Metadata Divalidasi via: OpenMetadata Service CEISA40-PostgreSQL-DWH
-- Target Database: PostgreSQL
-- ====================================================================

SELECT
    t.transaction_id,
    t.status
FROM dwh_ceisa.keberatan.fct_shipments AS t
LEFT JOIN dwh_ceisa.keberatan.fct_shipments AS t
    ON fct_transactions.transaction_id = t.transaction_id
WHERE
    t.transaction_date >= '2026-07-01 00:00:00'
  AND t.transaction_date <= '2026-09-30 23:59:59'
ORDER BY
    t.transaction_date DESC
LIMIT 500;
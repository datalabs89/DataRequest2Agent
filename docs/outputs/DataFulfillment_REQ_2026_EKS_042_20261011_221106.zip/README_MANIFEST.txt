================================================================================
PAKET PEMENUHAN PERMOHONAN DATA RESMI (DATA FULFILLMENT PACKAGE)
DataRequest Studio — Enterprise Data Requisition & Governance Platform
================================================================================
ID Permohonan      : REQ-2026-EKS-042
Dokumen            : SURAT PERMINTAAN DATA DUKUNG PENGAWASAN & AUDIT KEPATUHAN NEGARA
Pemohon            : Bambang Pratama, S.H., M.H. (Eksternal Kemenkeu)
Tujuan             : Data
Periode Data       : 01 Juli 2026 s/d 30 September 2026
Status Verifikasi  : APPROVED
Auditor            : Agent-Independent-Auditor-v2 (2026-10-11T15:11:06.617126+00:00)
Digital Fingerprint: SHA256:f8c5fd6a16cf5bdfe120d2d4f044c10df37e093ce7dfd30651ce041fb816166f
Proteksi PII       : Aktif (Masking NIK, Nama, dan No HP)

BERKAS DALAM PAKET INI:
1. DataExport_REQ_2026_EKS_042_20261011_221106.xlsx  - Workbook Excel (Data Hasil, Audit, Kamus Data)
2. DataExport_REQ_2026_EKS_042_20261011_221106.csv    - Raw Data CSV (UTF-8)
3. DataExport_REQ_2026_EKS_042_20261011_221106.json   - Raw Data JSON (Machine-Readable Records)
4. Sertifikat_Otorisasi_REQ_2026_EKS_042_20261011_221106.pdf   - Sertifikat Otorisasi & Tata Kelola Data (PDF)
5. query_audit.sql                  - Query SQL yang dieksekusi
6. request_specification.json       - Struktur spesifikasi kebutuhan hasil ekstraksi PDF
7. audit_verification_report.json   - Checklist kepatuhan dan jaminan keamanan
================================================================================
